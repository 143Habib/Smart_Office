/*

 *  Office Device Monitor — ESP32 Firmware
 *  Hackathon IUT 26 — Drawing Room (1 of 3 rooms)
 *  Devices: 3 Lights (15W each) + 2 Fans (60W each) = 165W max

 *  NO EXTERNAL LIBRARIES NEEDED — runs directly on Wokwi ESP32.
 *
 *  HOW IT WORKS:
 *    - 5 push buttons toggle 5 devices ON/OFF
 *    - 5 LEDs show the live state (yellow=lights, green=fans)
 *    - Potentiometer simulates an ACS712 current sensor
 *    - Serial Monitor outputs JSON telemetry every 2 seconds
 *      (simulates what ESP32 would send via Wi-Fi/MQTT to backend)
 *
 *  PIN MAP:
 *    OUTPUT (LEDs):   GPIO4=Light1, GPIO16=Light2, GPIO17=Light3,
 *                     GPIO18=Fan1,  GPIO19=Fan2
 *    INPUT (Buttons): GPIO13=SW_L1, GPIO12=SW_L2, GPIO14=SW_L3,
 *                     GPIO27=SW_F1, GPIO26=SW_F2
 *    ANALOG:          GPIO35=Current Sensor (potentiometer)
 
 */

// --- Output Pins (LEDs representing relay-controlled AC loads) ---
const int LIGHT1_PIN = 4;
const int LIGHT2_PIN = 16;
const int LIGHT3_PIN = 17;
const int FAN1_PIN   = 18;
const int FAN2_PIN   = 19;

// --- Input Pins (Push buttons as wall switches, active LOW) ---
const int SW_LIGHT1  = 13;
const int SW_LIGHT2  = 12;
const int SW_LIGHT3  = 14;
const int SW_FAN1    = 27;
const int SW_FAN2    = 26;

// --- Analog Input (Potentiometer simulating ACS712-30A) ---
const int CURRENT_SENSOR = 35;

// --- Power Ratings (Watts) ---
const float LIGHT_WATTS = 15.0;  // 15W LED tube light
const float FAN_WATTS   = 60.0;  // 60W ceiling fan

// --- Device State Arrays ---
const int NUM_LIGHTS = 3;
const int NUM_FANS   = 2;

int lightPins[]   = {LIGHT1_PIN, LIGHT2_PIN, LIGHT3_PIN};
int lightSwPins[] = {SW_LIGHT1,  SW_LIGHT2,  SW_LIGHT3};
bool lightOn[]    = {false, false, false};

int fanPins[]     = {FAN1_PIN, FAN2_PIN};
int fanSwPins[]   = {SW_FAN1,  SW_FAN2};
bool fanOn[]      = {false, false};

// --- Debounce ---
unsigned long lastLightPress[] = {0, 0, 0};
unsigned long lastFanPress[]   = {0, 0};
const unsigned long DEBOUNCE   = 300;  // ms

// --- Reporting ---
unsigned long lastReport = 0;
const unsigned long REPORT_INTERVAL = 2000;  // ms

// ================================================================
//  SETUP
// ================================================================
void setup() {
  Serial.begin(115200);
  delay(300);

  // Configure LED output pins
  for (int i = 0; i < NUM_LIGHTS; i++) {
    pinMode(lightPins[i], OUTPUT);
    digitalWrite(lightPins[i], LOW);
  }
  for (int i = 0; i < NUM_FANS; i++) {
    pinMode(fanPins[i], OUTPUT);
    digitalWrite(fanPins[i], LOW);
  }

  // Configure button input pins with internal pull-up
  for (int i = 0; i < NUM_LIGHTS; i++) {
    pinMode(lightSwPins[i], INPUT_PULLUP);
  }
  for (int i = 0; i < NUM_FANS; i++) {
    pinMode(fanSwPins[i], INPUT_PULLUP);
  }

  // Configure analog input
  analogReadResolution(12);
  pinMode(CURRENT_SENSOR, INPUT);

  Serial.println("==========================================");
  Serial.println("  OFFICE DEVICE MONITOR v1.0");
  Serial.println("  Room: Drawing Room");
  Serial.println("  3 Lights (15W) + 2 Fans (60W) = 165W");
  Serial.println("==========================================");
  Serial.println("  Press buttons to toggle devices ON/OFF");
  Serial.println("  Watch Serial Monitor for JSON telemetry");
  Serial.println("==========================================");
  Serial.println();
}

void loop() {
  // 1. Read light switches
  for (int i = 0; i < NUM_LIGHTS; i++) {
    if (digitalRead(lightSwPins[i]) == LOW) {
      if (millis() - lastLightPress[i] > DEBOUNCE) {
        lightOn[i] = !lightOn[i];
        digitalWrite(lightPins[i], lightOn[i] ? HIGH : LOW);
        lastLightPress[i] = millis();

        Serial.print("[TOGGLE] Light ");
        Serial.print(i + 1);
        Serial.print(" -> ");
        Serial.println(lightOn[i] ? "ON" : "OFF");
      }
    }
  }

  // 2. Read fan switches
  for (int i = 0; i < NUM_FANS; i++) {
    if (digitalRead(fanSwPins[i]) == LOW) {
      if (millis() - lastFanPress[i] > DEBOUNCE) {
        fanOn[i] = !fanOn[i];
        digitalWrite(fanPins[i], fanOn[i] ? HIGH : LOW);
        lastFanPress[i] = millis();

        Serial.print("[TOGGLE] Fan ");
        Serial.print(i + 1);
        Serial.print(" -> ");
        Serial.println(fanOn[i] ? "ON" : "OFF");
      }
    }
  }

  // 3. Periodic JSON status report (simulates MQTT publish)
  if (millis() - lastReport >= REPORT_INTERVAL) {
    reportJSON();
    lastReport = millis();
  }

  delay(50);
}


void reportJSON() {
  // Calculate power
  float totalPower = 0;
  int lightsOnCount = 0;
  int fansOnCount = 0;

  for (int i = 0; i < NUM_LIGHTS; i++) {
    if (lightOn[i]) { totalPower += LIGHT_WATTS; lightsOnCount++; }
  }
  for (int i = 0; i < NUM_FANS; i++) {
    if (fanOn[i]) { totalPower += FAN_WATTS; fansOnCount++; }
  }

  // Read current sensor (potentiometer simulation)
  int rawADC = analogRead(CURRENT_SENSOR);
  
  // The sensor power automatically tracks the turned-on lights and fans (totalPower)
  // Plus, the potentiometer simulates "Other Desk Loads" (like computers, chargers, 0 to 500W)
  float deskLoads = (rawADC / 4095.0) * 500.0;
  
  // Add a tiny random fluctuation (+/- 1.5W) to make the sensor readings look alive
  float noise = 0.0;
  if (totalPower > 0 || deskLoads > 0) {
    noise = (random(-15, 15) / 10.0);
  }
  
  float sensorPower = totalPower + deskLoads + noise;
  if (sensorPower < 0) sensorPower = 0.0;

  // Print JSON
  Serial.println("{");
  Serial.println("  \"room\": \"drawing_room\",");
  Serial.println("  \"devices\": [");

  // Lights
  for (int i = 0; i < NUM_LIGHTS; i++) {
    Serial.print("    {\"id\": \"DR_Light_");
    Serial.print(i + 1);
    Serial.print("\", \"type\": \"light\", \"status\": ");
    Serial.print(lightOn[i] ? "true" : "false");
    Serial.print(", \"watts\": ");
    Serial.print(lightOn[i] ? LIGHT_WATTS : 0, 0);
    Serial.print("}");
    Serial.println(",");
  }

  // Fans
  for (int i = 0; i < NUM_FANS; i++) {
    Serial.print("    {\"id\": \"DR_Fan_");
    Serial.print(i + 1);
    Serial.print("\", \"type\": \"fan\", \"status\": ");
    Serial.print(fanOn[i] ? "true" : "false");
    Serial.print(", \"watts\": ");
    Serial.print(fanOn[i] ? FAN_WATTS : 0, 0);
    Serial.print("}");
    if (i < NUM_FANS - 1) Serial.print(",");
    Serial.println();
  }

  Serial.println("  ],");
  Serial.print("  \"lights_on\": "); Serial.print(lightsOnCount); Serial.println(",");
  Serial.print("  \"fans_on\": "); Serial.print(fansOnCount); Serial.println(",");
  Serial.print("  \"total_power_w\": "); Serial.print(totalPower, 0); Serial.println(",");
  Serial.print("  \"sensor_power_w\": "); Serial.println(sensorPower, 1);
  Serial.println("}");
  Serial.println();
}
